# Student Fee Management System

A simple hackathon-ready web app for a college accounts office.

## Features
- Add and maintain student records (unique student ID, name and course).
- Assign a total fee to each student.
- Record multiple full or partial instalment payments with date and optional note.
- Automatically calculate total paid and remaining balance.
- Automatically show Fully Paid, Partially Paid or Unpaid status.
- Search by student name, ID or course and filter by payment status.
- Persist records in a local JSON file (`data/students.json`).

## Technology
- Frontend: HTML, CSS and vanilla JavaScript.
- Backend: Node.js and Express REST API.
- Demo storage: JSON file (no database installation required).

## Run locally
1. Install Node.js (LTS).
2. Open a terminal in this project folder.
3. Run `npm install`.
4. Run `npm start`.
5. Open `http://localhost:3000` in your browser.

The server creates `data/students.json` automatically on first run.

## Main API routes
- `GET /api/students?search=&status=` — list, search and filter students.
- `POST /api/students` — create a student and assign total fee.
- `GET /api/students/:id` — retrieve one student and payment summary.
- `POST /api/students/:id/payments` — add a payment instalment.

### Example: create student
```json
{
  "studentId": "CSE2026-01",
  "name": "Ananya Rao",
  "course": "B.Tech CSE",
  "totalFee": 85000
}
```

### Example: add payment
```json
{
  "amount": 20000,
  "date": "2026-11-10",
  "note": "First instalment"
}
```

## Important hackathon note
This is a working local prototype, not a production college finance system. For real deployment, use a database such as PostgreSQL/MySQL, authentication and role-based access, audit logs, backups, HTTPS, and server-side authorization. Protect student financial and personal information. The dashboard totals currently reflect the visible filtered results.
