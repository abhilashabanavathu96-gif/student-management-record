const API = "/api";
const studentRows = document.getElementById("studentRows");
const studentForm = document.getElementById("studentForm");
const formMessage = document.getElementById("formMessage");
const searchInput = document.getElementById("searchInput");
const statusFilter = document.getElementById("statusFilter");
const paymentDialog = document.getElementById("paymentDialog");
const paymentForm = document.getElementById("paymentForm");
const paymentMessage = document.getElementById("paymentMessage");

const money = value => new Intl.NumberFormat("en-IN", {
  style: "currency", currency: "INR", minimumFractionDigits: 2
}).format(Number(value || 0));

function escapeHTML(value) {
  return String(value).replace(/[&<>"']/g, ch => ({
    "&":"&amp;", "<":"&lt;", ">":"&gt;", '"':"&quot;", "'":"&#039;"
  })[ch]);
}

async function request(url, options = {}) {
  const response = await fetch(url, {
    headers: { "Content-Type": "application/json" },
    ...options
  });
  const data = await response.json();
  if (!response.ok) throw new Error(data.message || "Something went wrong.");
  return data;
}

async function loadStudents() {
  const params = new URLSearchParams({
    search: searchInput.value.trim(),
    status: statusFilter.value
  });
  try {
    const students = await request(`${API}/students?${params}`);
    renderStudents(students);
    updateSummary(students);
  } catch (error) {
    studentRows.innerHTML = `<tr><td colspan="6" class="empty">${escapeHTML(error.message)}</td></tr>`;
  }
}

function updateSummary(students) {
  // The displayed summary follows the current filtered list.
  document.getElementById("studentCount").textContent = students.length;
  document.getElementById("collected").textContent = money(students.reduce((sum,s) => sum + s.totalPaid, 0));
  document.getElementById("outstanding").textContent = money(students.reduce((sum,s) => sum + s.balance, 0));
}

function renderStudents(students) {
  if (!students.length) {
    studentRows.innerHTML = '<tr><td colspan="6" class="empty">No student records found. Add a student to get started.</td></tr>';
    return;
  }
  studentRows.innerHTML = students.map(s => {
    const statusClass = s.status.toLowerCase().replaceAll(" ", "-");
    return `<tr>
      <td><span class="student-name">${escapeHTML(s.name)}</span><span class="student-sub">${escapeHTML(s.studentId)} · ${escapeHTML(s.course)}</span></td>
      <td>${money(s.totalFee)}</td><td>${money(s.totalPaid)}</td><td><strong>${money(s.balance)}</strong></td>
      <td><span class="status ${statusClass}">${escapeHTML(s.status)}</span></td>
      <td><button class="action-btn" data-id="${escapeHTML(s.id)}" data-name="${escapeHTML(s.name)}" data-balance="${s.balance}" ${s.balance <= 0 ? "disabled" : ""}>＋ Payment</button></td>
    </tr>`;
  }).join("");
}

studentForm.addEventListener("submit", async event => {
  event.preventDefault();
  formMessage.textContent = "";
  const formData = new FormData(studentForm);
  const payload = Object.fromEntries(formData.entries());
  payload.totalFee = Number(payload.totalFee);
  try {
    await request(`${API}/students`, { method: "POST", body: JSON.stringify(payload) });
    studentForm.reset();
    formMessage.style.color = "#16845b";
    formMessage.textContent = "Student record added successfully.";
    await loadStudents();
  } catch (error) {
    formMessage.style.color = "#b54747";
    formMessage.textContent = error.message;
  }
});

studentRows.addEventListener("click", event => {
  const button = event.target.closest("button[data-id]");
  if (!button) return;
  paymentForm.elements.studentDbId.value = button.dataset.id;
  document.getElementById("paymentStudent").textContent = button.dataset.name;
  document.getElementById("paymentBalance").textContent = `Remaining balance: ${money(button.dataset.balance)}`;
  paymentForm.elements.amount.max = button.dataset.balance;
  paymentForm.elements.date.value = new Date().toISOString().slice(0, 10);
  paymentMessage.textContent = "";
  paymentDialog.showModal();
});

paymentForm.addEventListener("submit", async event => {
  event.preventDefault();
  const studentId = paymentForm.elements.studentDbId.value;
  const payload = {
    amount: Number(paymentForm.elements.amount.value),
    date: paymentForm.elements.date.value,
    note: paymentForm.elements.note.value
  };
  try {
    await request(`${API}/students/${encodeURIComponent(studentId)}/payments`, {
      method: "POST", body: JSON.stringify(payload)
    });
    paymentDialog.close();
    paymentForm.reset();
    await loadStudents();
  } catch (error) {
    paymentMessage.textContent = error.message;
  }
});

document.getElementById("closeDialog").addEventListener("click", () => paymentDialog.close());
searchInput.addEventListener("input", loadStudents);
statusFilter.addEventListener("change", loadStudents);

loadStudents();