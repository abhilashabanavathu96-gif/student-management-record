const express = require("express");
const fs = require("fs");
const path = require("path");

const app = express();
const PORT = process.env.PORT || 3000;
const DATA_DIR = path.join(__dirname, "data");
const DATA_FILE = path.join(DATA_DIR, "students.json");

app.use(express.json());
app.use(express.static(path.join(__dirname, "public")));

if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });
if (!fs.existsSync(DATA_FILE)) fs.writeFileSync(DATA_FILE, "[]", "utf8");

function readStudents() {
  try {
    const data = JSON.parse(fs.readFileSync(DATA_FILE, "utf8"));
    return Array.isArray(data) ? data : [];
  } catch {
    return [];
  }
}
function writeStudents(students) {
  fs.writeFileSync(DATA_FILE, JSON.stringify(students, null, 2), "utf8");
}
function getTotals(student) {
  const paid = student.payments.reduce((sum, p) => sum + Number(p.amount), 0);
  const balance = Math.max(0, Number(student.totalFee) - paid);
  let status = "Unpaid";
  if (paid >= Number(student.totalFee)) status = "Fully Paid";
  else if (paid > 0) status = "Partially Paid";
  return { totalPaid: paid, balance, status };
}
function withSummary(student) {
  return { ...student, ...getTotals(student) };
}

// Get all students; optional search and status filters
app.get("/api/students", (req, res) => {
  const search = String(req.query.search || "").trim().toLowerCase();
  const status = String(req.query.status || "").trim().toLowerCase();
  let students = readStudents().map(withSummary);

  if (search) {
    students = students.filter(s =>
      s.name.toLowerCase().includes(search) ||
      s.studentId.toLowerCase().includes(search) ||
      s.course.toLowerCase().includes(search)
    );
  }
  if (status && status !== "all") {
    students = students.filter(s => s.status.toLowerCase() === status);
  }
  res.json(students);
});

// Add a student and assign their total fee
app.post("/api/students", (req, res) => {
  const { studentId, name, course, totalFee } = req.body;
  if (![studentId, name, course].every(v => typeof v === "string" && v.trim())) {
    return res.status(400).json({ message: "Student ID, name and course are required." });
  }
  const fee = Number(totalFee);
  if (!Number.isFinite(fee) || fee <= 0) {
    return res.status(400).json({ message: "Total fee must be a number greater than zero." });
  }

  const students = readStudents();
  if (students.some(s => s.studentId.toLowerCase() === studentId.trim().toLowerCase())) {
    return res.status(409).json({ message: "That student ID already exists." });
  }

  const student = {
    id: Date.now().toString(),
    studentId: studentId.trim(),
    name: name.trim(),
    course: course.trim(),
    totalFee: fee,
    payments: [],
    createdAt: new Date().toISOString()
  };
  students.push(student);
  writeStudents(students);
  res.status(201).json(withSummary(student));
});

// Record a full or partial instalment
app.post("/api/students/:id/payments", (req, res) => {
  const amount = Number(req.body.amount);
  const date = req.body.date ? new Date(req.body.date) : new Date();

  if (!Number.isFinite(amount) || amount <= 0) {
    return res.status(400).json({ message: "Payment amount must be greater than zero." });
  }
  if (Number.isNaN(date.getTime())) {
    return res.status(400).json({ message: "Please provide a valid payment date." });
  }

  const students = readStudents();
  const student = students.find(s => s.id === req.params.id);
  if (!student) return res.status(404).json({ message: "Student not found." });

  const totals = getTotals(student);
  if (amount > totals.balance) {
    return res.status(400).json({ message: `Payment exceeds the remaining balance of ${totals.balance.toFixed(2)}.` });
  }

  student.payments.push({
    id: Date.now().toString(),
    amount,
    date: date.toISOString().slice(0, 10),
    note: String(req.body.note || "").trim()
  });
  writeStudents(students);
  res.status(201).json(withSummary(student));
});

// Get one student with their payment history
app.get("/api/students/:id", (req, res) => {
  const student = readStudents().find(s => s.id === req.params.id);
  if (!student) return res.status(404).json({ message: "Student not found." });
  res.json(withSummary(student));
});

app.listen(PORT, () => {
  console.log(`Student Fee Management System running at http://localhost:${PORT}`);
});